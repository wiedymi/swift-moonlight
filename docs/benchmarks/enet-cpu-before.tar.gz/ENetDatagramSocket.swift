import Darwin
import Dispatch
import Foundation

/// The lock serializes nonblocking descriptor operations with cancellation.
/// Only the read source closes the descriptor, after its handler has stopped.
/// At most 256 raw packets wait under this lock. A coalesced notification
/// wakes the reader; reliable delivery recovers packets dropped at capacity.
final class ENetDatagramSocket: @unchecked Sendable {
    let readiness: AsyncThrowingStream<Void, any Error>
    let port: UInt16
    private let descriptor: Int32
    private let source: DispatchSourceRead
    private let continuation: AsyncThrowingStream<Void, any Error>.Continuation
    private let lock = NSLock()
    private var closed = false
    private var pending: [Data] = []
    private var receiveBuffer = [UInt8](repeating: 0, count: 4097)

    static func open(host: String, port: UInt16) async throws -> ENetDatagramSocket {
        let opening = ENetSocketOpening()
        let socket = try await withTaskCancellationHandler {
            try await opening.start { try ENetDatagramSocket(host: host, port: port) }
        } onCancel: {
            Task { await opening.cancel() }
        }
        if Task.isCancelled { socket.close(); throw CancellationError() }
        return socket
    }

    init(host: String, port: UInt16) throws {
        var hints = addrinfo()
        hints.ai_family = AF_UNSPEC
        hints.ai_socktype = SOCK_DGRAM
        hints.ai_protocol = IPPROTO_UDP
        var addresses: UnsafeMutablePointer<addrinfo>?
        let result = getaddrinfo(host, String(port), &hints, &addresses)
        guard result == 0, let addresses else { throw ENetError.invalidConnect }
        defer { freeaddrinfo(addresses) }
        var candidate: UnsafeMutablePointer<addrinfo>? = addresses
        var candidates: [UnsafeMutablePointer<addrinfo>] = []
        while let address = candidate {
            candidates.append(address); candidate = address.pointee.ai_next
        }
        // Preserve the previous IPv4 hostname path when both families exist.
        // Explicit IPv6 addresses and IPv6-only names still use IPv6.
        candidates.sort { $0.pointee.ai_family == AF_INET && $1.pointee.ai_family != AF_INET }
        var selected: Int32 = -1
        for address in candidates {
            let fd = Darwin.socket(address.pointee.ai_family, SOCK_DGRAM, IPPROTO_UDP)
            if fd >= 0 {
                let flags = fcntl(fd, F_GETFL, 0)
                if flags >= 0, fcntl(fd, F_SETFL, flags | O_NONBLOCK) == 0,
                   Darwin.connect(fd, address.pointee.ai_addr, address.pointee.ai_addrlen) == 0 {
                    selected = fd; break
                }
                Darwin.close(fd)
            }
        }
        guard selected >= 0 else { throw ENetError.invalidConnect }
        var local = sockaddr_storage()
        var length = socklen_t(MemoryLayout<sockaddr_storage>.size)
        let query = withUnsafeMutablePointer(to: &local) {
            $0.withMemoryRebound(to: sockaddr.self, capacity: 1) { getsockname(selected, $0, &length) }
        }
        guard query == 0 else { Darwin.close(selected); throw ENetError.invalidConnect }
        let localPort = withUnsafePointer(to: local) { pointer -> UInt16 in
            if Int32(local.ss_family) == AF_INET6 {
                return pointer.withMemoryRebound(to: sockaddr_in6.self, capacity: 1) { UInt16(bigEndian: $0.pointee.sin6_port) }
            }
            return pointer.withMemoryRebound(to: sockaddr_in.self, capacity: 1) { UInt16(bigEndian: $0.pointee.sin_port) }
        }
        descriptor = selected
        self.port = localPort
        var bufferSize: Int32 = 256 * 1024
        _ = setsockopt(selected, SOL_SOCKET, SO_RCVBUF, &bufferSize, socklen_t(MemoryLayout<Int32>.size))
        let pair = AsyncThrowingStream<Void, any Error>.makeStream(bufferingPolicy: .bufferingNewest(1))
        readiness = pair.stream; continuation = pair.continuation
        source = DispatchSource.makeReadSource(fileDescriptor: selected, queue: DispatchQueue(label: "swift-moonlight.enet.udp"))
        source.setEventHandler { [weak self] in self?.readAvailable() }
        source.setCancelHandler { Darwin.close(selected) }
        source.resume()
    }

    deinit { close() }

    func send(_ packet: Data) throws {
        lock.lock(); defer { lock.unlock() }
        guard !closed else { throw ENetError.closed }
        let count = packet.withUnsafeBytes { Darwin.send(descriptor, $0.baseAddress, $0.count, 0) }
        if count == packet.count { return }
        if count < 0 && Self.isTransient(errno) { return }
        throw MoonlightError(.unsupportedOperation, message: "ENet UDP send failed")
    }

    func close() {
        lock.lock(); defer { lock.unlock() }
        guard !closed else { return }
        closed = true
        pending.removeAll()
        source.cancel()
        continuation.finish()
    }

    func takePackets() -> [Data] {
        lock.lock(); defer { lock.unlock() }
        let packets = pending
        pending = []
        return packets
    }

    private func readAvailable() {
        lock.lock(); defer { lock.unlock() }
        guard !closed else { return }
        var added = false
        // One notification covers all queued datagrams. No delay is added;
        // the reader takes the packets already available under the same lock.
        defer { if added { continuation.yield(()) } }
        // One extra byte distinguishes an oversized datagram without truncating it
        // into an apparently valid protocol message.
        for _ in 0..<64 {
            let count = recv(descriptor, &receiveBuffer, receiveBuffer.count, 0)
            if count >= 0 {
                if count > 0 && count <= 4096 && pending.count < 256 {
                    pending.append(receiveBuffer.withUnsafeBytes { Data(bytes: $0.baseAddress!, count: count) })
                    added = true
                }
                continue
            }
            if errno == EINTR { continue }
            if Self.isTransient(errno) { return }
            continuation.finish(throwing: MoonlightError(.unsupportedOperation, message: "ENet UDP receive failed"))
            return
        }
    }

    private static func isTransient(_ code: Int32) -> Bool {
        [EAGAIN, EWOULDBLOCK, EINTR, ECONNREFUSED, ECONNRESET, ENETUNREACH, EHOSTUNREACH, ENOBUFS].contains(code)
    }
}

/// Address lookup itself is a system call. Cancellation releases the caller
/// immediately; a late worker result closes its descriptor instead of escaping.
actor ENetSocketOpening {
    private enum State {
        case idle
        case waiting(CheckedContinuation<ENetDatagramSocket, any Error>)
        case cancelled
        case finished
    }
    private var state: State = .idle

    func start(create: @escaping @Sendable () throws -> ENetDatagramSocket) async throws -> ENetDatagramSocket {
        try Task.checkCancellation()
        return try await withCheckedThrowingContinuation { continuation in
            switch state {
            case .cancelled: continuation.resume(throwing: CancellationError())
            case .finished, .waiting: continuation.resume(throwing: ENetError.closed)
            case .idle:
                state = .waiting(continuation)
                Task.detached { await self.finish(Result { try create() }) }
            }
        }
    }

    func cancel() {
        switch state {
        case .idle: state = .cancelled
        case .waiting(let continuation):
            state = .cancelled
            continuation.resume(throwing: CancellationError())
        case .cancelled, .finished: break
        }
    }

    private func finish(_ result: Result<ENetDatagramSocket, any Error>) {
        switch state {
        case .waiting(let continuation):
            state = .finished
            continuation.resume(with: result)
        case .idle, .cancelled, .finished:
            if case .success(let socket) = result { socket.close() }
            state = .finished
        }
    }
}
