import Dispatch
import Foundation

public final class ENetControlSession: Sendable {
    fileprivate let connection: ENetConnection
    public var controlEncryption: ControlEncryptionContext? { connection.encryption }

    public init(remoteHost: String, remotePort: UInt16, connectData: UInt32,
                controlEncryption: ControlEncryptionContext?) async throws {
        // Name resolution runs outside the caller's actor.
        let socket: ENetDatagramSocket
        do {
            socket = try await ENetDatagramSocket.open(host: remoteHost, port: remotePort)
        } catch { throw transportError(error) }
        connection = ENetConnection(socket: socket, connectData: connectData, encryption: controlEncryption)
        do { try await connection.connect() }
        catch { await connection.close(); throw transportError(error) }
    }

    deinit {
        let connection = connection
        Task { await connection.close() }
    }

    public func close() async { await connection.close() }
    static var periodicPingUsesReliableDelivery: Bool { true }
    static func makePeriodicPingPayload() -> Data { Data([4, 0, 0, 0, 0, 0, 0, 0]) }
}

fileprivate actor ENetConnection {
    private let socket: ENetDatagramSocket
    nonisolated let encryption: ControlEncryptionContext?
    private var peer: ENetPeer
    private let crypto = ControlPacketCrypto()
    private var encryptionSequence: UInt64 = 0
    private var receiveTask: Task<Void, Never>?
    private struct ScheduledTimer { var deadline: UInt64; var task: Task<Void, Never> }
    private var timer: ScheduledTimer?
    private var terminalError: (any Error)?
    private var connectWaiter: CheckedContinuation<Void, any Error>?
    private struct PacketWaiter {
        var id: UUID
        var continuation: CheckedContinuation<Data?, any Error>
    }
    private var packetWaiter: PacketWaiter?
    private var packets: [Data] = []
    private var packetIndex = 0
    private var packetBytes = 0
    private var nextApplicationPing: UInt64?

    private static var now: UInt64 { DispatchTime.now().uptimeNanoseconds / 1_000_000 }

    init(socket: ENetDatagramSocket, connectData: UInt32, encryption: ControlEncryptionContext?) {
        self.socket = socket; self.encryption = encryption
        peer = ENetPeer(connectID: UInt32.random(in: .min ... .max), connectData: connectData, now: Self.now)
    }

    func connect() async throws {
        try Task.checkCancellation()
        try await withTaskCancellationHandler {
            try await withCheckedThrowingContinuation { continuation in
                connectWaiter = continuation
                receiveTask = Task { [weak self, socket] in
                    do {
                        for try await _ in socket.readiness {
                            guard !Task.isCancelled else { return }
                            await self?.receive(socket.takePackets())
                        }
                        await self?.finish(error: nil)
                    } catch { await self?.finish(error: error) }
                }
                do { try pump() } catch { finish(error: error) }
            }
        } onCancel: {
            Task { await self.finish(error: CancellationError()) }
        }
    }

    func send(_ packet: Data, channel: UInt8, reliable: Bool) throws {
        try peer.enqueue(packet, channel: channel, delivery: reliable ? .reliable : .unreliable)
        try pump()
    }

    func sendPayload(type: UInt16, payload: Data, channel: UInt8, reliable: Bool,
                     encryption: ControlEncryptionContext?) throws {
        guard peer.state == .connected else { throw ENetError.notConnected }
        let packet: Data
        if let encryption {
            // Crypto framing has a 16-bit length; reject before converting it.
            guard payload.count <= 65_511 else { throw ENetError.messageTooLarge }
            guard encryptionSequence <= UInt64(UInt32.max) else { throw ENetError.messageTooLarge }
            packet = try crypto.seal(packetType: type, payload: payload, sequenceNumber: UInt32(encryptionSequence),
                                     sender: .client, context: encryption)
            encryptionSequence += 1
        } else {
            guard payload.count <= ENetPeer.maximumMessageSize - 2 else { throw ENetError.messageTooLarge }
            var plain = Data([UInt8(truncatingIfNeeded: type), UInt8(truncatingIfNeeded: type >> 8)])
            plain.append(payload); packet = plain
        }
        try send(packet, channel: channel, reliable: reliable)
    }

    func receivePacket() async throws -> Data? {
        try Task.checkCancellation()
        if packetIndex < packets.count {
            let packet = packets[packetIndex]
            // Release consumed storage before the next array compaction.
            packets[packetIndex] = Data()
            packetIndex += 1; packetBytes -= packet.count
            if packetIndex == packets.count { packets.removeAll(keepingCapacity: true); packetIndex = 0 }
            return packet
        }
        if case .closed(let error) = peer.state {
            if let terminalError { throw terminalError }
            if let error { throw error }
            return nil
        }
        guard packetWaiter == nil else { throw MoonlightError(.invalidStateTransition, message: "ENet permits one packet reader") }
        let id = UUID()
        return try await withTaskCancellationHandler {
            try await withCheckedThrowingContinuation { packetWaiter = PacketWaiter(id: id, continuation: $0) }
        } onCancel: {
            Task { await self.cancelRead(id: id) }
        }
    }

    private func cancelRead(id: UUID) {
        // A delayed cancellation must not cancel a later reader.
        guard packetWaiter?.id == id else { return }
        packetWaiter?.continuation.resume(throwing: CancellationError()); packetWaiter = nil
    }

    func localPort() -> UInt16 { socket.port }
    func metrics() -> ControlTransportMetricsSnapshot { peer.metrics }

    private func receive(_ packets: [Data]) {
        do {
            for packet in packets {
                let wasConnecting = peer.state == .connecting
                try apply(peer.receive(packet, now: Self.now, flushACKs: false))
                if wasConnecting, peer.state == .connected {
                    let type: UInt16 = encryption == nil ? 0x0305 : 0x0302
                    try sendPayload(type: type, payload: Data([0, 0]), channel: 0, reliable: true, encryption: encryption)
                    try sendPayload(type: 0x0307, payload: Data([0]), channel: 0, reliable: true, encryption: encryption)
                    nextApplicationPing = Self.now
                    connectWaiter?.resume(); connectWaiter = nil
                }
            }
            try pump()
        } catch { finish(error: error) }
    }

    private func apply(_ output: ENetPeer.Output) throws {
        for datagram in output.datagrams { try socket.send(datagram) }
        for packet in output.packets {
            if let waiter = packetWaiter {
                packetWaiter = nil; waiter.continuation.resume(returning: packet)
            } else {
                guard packetBytes <= ENetPeer.maximumQueuedBytes - packet.count,
                      packets.count - packetIndex < 4096 else { throw ENetError.queueFull }
                if packetIndex >= 256 { packets.removeFirst(packetIndex); packetIndex = 0 }
                packets.append(packet); packetBytes += packet.count
            }
        }
    }

    private func pump() throws {
        if case .closed(let error) = peer.state { finish(error: error); return }
        let now = Self.now
        if let ping = nextApplicationPing, now >= ping, peer.state == .connected {
            // Queue directly; do not recurse into pump from the timer.
            let payload = ENetControlSession.makePeriodicPingPayload()
            let packet: Data
            if let encryption {
                guard encryptionSequence <= UInt64(UInt32.max) else { throw ENetError.messageTooLarge }
                packet = try crypto.seal(packetType: 0x0200, payload: payload,
                                         sequenceNumber: UInt32(encryptionSequence), sender: .client, context: encryption)
                encryptionSequence += 1
            } else { packet = Data([0, 2]) + payload }
            try peer.enqueue(packet, channel: 0, delivery: .reliable)
            nextApplicationPing = now + 100
        }
        try apply(peer.service(now: now))
        if case .closed(let error) = peer.state { finish(error: error); return }
        let deadline = min(peer.nextServiceTime ?? now + 100, nextApplicationPing ?? UInt64.max)
        let scheduledDeadline = max(now + 1, deadline)
        // Keep an earlier wait. ACKs usually remove a retry before it is due;
        // replacing a sleeping task for every ACK adds needless CPU work.
        if let timer, timer.deadline <= scheduledDeadline { return }
        timer?.task.cancel()
        let delay = scheduledDeadline - now
        let task = Task { [weak self] in
            do { try await Task.sleep(for: .milliseconds(Int64(delay))) }
            catch { return }
            await self?.timerFired(deadline: scheduledDeadline)
        }
        timer = ScheduledTimer(deadline: scheduledDeadline, task: task)
    }

    private func timerFired(deadline: UInt64) {
        guard !Task.isCancelled, timer?.deadline == deadline else { return }
        timer = nil
        do { try pump() } catch { finish(error: error) }
    }

    func close() {
        for datagram in peer.close(now: Self.now).datagrams { try? socket.send(datagram) }
        finish(error: nil)
    }

    private func finish(error: (any Error)?) {
        if let error, !(error is ENetError) { terminalError = error }
        _ = peer.close(now: Self.now)
        socket.close(); receiveTask?.cancel(); receiveTask = nil
        timer?.task.cancel(); timer = nil; nextApplicationPing = nil
        if let waiter = connectWaiter { connectWaiter = nil; waiter.resume(throwing: error ?? ENetError.closed) }
        if let waiter = packetWaiter {
            packetWaiter = nil
            if let error { waiter.continuation.resume(throwing: error) } else { waiter.continuation.resume(returning: nil) }
        }
    }
}

public actor ENetControlChannelTransport: TypedControlPacketTransport, ControlTransportMetricsReporting, LocalPortReporting, ClosableTransport {
    private let session: ENetControlSession
    public init(session: ENetControlSession) { self.session = session }
    public nonisolated func send(packet: Data, channelID: UInt8, reliable: Bool) async throws {
        do { try await session.connection.send(packet, channel: channelID, reliable: reliable) }
        catch { throw transportError(error) }
    }
    public nonisolated func sendControlPayload(packetType: UInt16, payload: Data, channelID: UInt8, reliable: Bool,
                                   encryption: ControlEncryptionContext?) async throws {
        do {
            try await session.connection.sendPayload(type: packetType, payload: payload, channel: channelID,
                                                      reliable: reliable, encryption: encryption)
        } catch { throw transportError(error) }
    }
    public nonisolated func receivePacket() async throws -> Data? {
        do { return try await session.connection.receivePacket() }
        catch { throw transportError(error) }
    }
    public nonisolated func localPort() async throws -> UInt16 { await session.connection.localPort() }
    public nonisolated func snapshotControlTransportMetrics() async -> ControlTransportMetricsSnapshot { await session.connection.metrics() }
    public nonisolated func close() async { await session.close() }
}

public actor ENetInputPacketTransport: InputPacketTransport, LocalPortReporting, ClosableTransport {
    private let session: ENetControlSession
    public init(session: ENetControlSession) { self.session = session }
    public nonisolated func send(_ packet: Data, channelID: UInt8, reliable: Bool) async throws {
        do {
            try await session.connection.sendPayload(type: 0x0206, payload: packet, channel: channelID,
                                                      reliable: reliable, encryption: session.controlEncryption)
        } catch { throw transportError(error) }
    }
    public nonisolated func localPort() async throws -> UInt16 { await session.connection.localPort() }
    public nonisolated func close() async { await session.close() }
}

private func transportError(_ error: any Error) -> any Error {
    guard let error = error as? ENetError else { return error }
    switch error {
    case .invalidPacket: return MoonlightError(.invalidControlMessage, message: "Invalid ENet packet")
    case .invalidConnect: return MoonlightError(.networkRequestFailed, message: "ENet connection setup failed")
    case .timedOut: return MoonlightError(.networkRequestFailed, message: "ENet connection timed out")
    case .notConnected, .closed: return MoonlightError(.invalidStateTransition, message: "ENet connection is closed")
    case .queueFull: return MoonlightError(.unsupportedOperation, message: "ENet queue limit exceeded")
    case .messageTooLarge: return MoonlightError(.unsupportedOperation, message: "ENet message size or sequence limit exceeded")
    }
}
